# GR 2026 AAE — Cadeados e sons
Simulador independente, não oficial. Aplicativo Android offline, sem permissões de internet. HTML incorporado em `app/src/main/assets/index.html`.

## Gerar APK pelo GitHub
1. Extraia o ZIP. Crie um repositório vazio no GitHub.
2. Envie todos os arquivos extraídos **na raiz do repositório**, incluindo a pasta oculta `.github` (ela contém `.github/workflows/build-apk.yml`). Se o envio pelo navegador omitir essa pasta, crie manualmente esse arquivo no GitHub copiando o conteúdo do ZIP, ou envie usando Git/GitHub Desktop.
3. Abra **Actions > Gerar APK GR 2026 > Run workflow**. O envio para `main` ou `master` também dispara a compilação.
4. Quando a execução concluir com sucesso, abra a execução e baixe o artefato **GR_2026_AAE_APK**. Extraia o ZIP do artefato para obter `GR_2026_AAE.apk`.
5. Abra o APK no Android. O Android pode solicitar autorização para instalar apps dessa fonte. O APK é de teste (debug), não é um pacote de publicação na Play Store.

## Compilar localmente
Com JDK 17, Gradle 8.9 e Android SDK (API 35 e build-tools 35.0.0) configurados, execute `gradle :app:assembleDebug` na raiz. O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.

## Como funciona
- Nove switches individuais: cinza/aberto = livre, verde/fechado = protegido. A trava desabilita o slider e o campo manual correspondente e é respeitada pelos botões de cenário, máximo e reset.
- As travas, os números e a preferência sonora são guardados localmente, se o armazenamento estiver disponível. Não há conta nem sincronização entre navegador e APK. O teto e os demais critérios livres continuam podendo modificar o total.
- Clique crepitante durante o movimento das barras, dois sons distintos para travar/destravar e botão de silenciar. O áudio depende do WebView, do volume e da permissão de reprodução após interação.
- Fórmulas originais mantidas, incluindo aviso de simulação não oficial.

## Observações
O fluxo produz APK de debug. A chave de assinatura pode mudar entre execuções em máquinas diferentes. Para futuras atualizações sem desinstalar o aplicativo, configure uma chave de assinatura persistente e mantenha o mesmo applicationId. Desinstalar pode apagar os valores guardados. O projeto usa um novo identificador `br.com.gr2026.aae`; não foi vinculado a um repositório ou assinatura anterior. A compilação Android deve ser validada no GitHub Actions.
